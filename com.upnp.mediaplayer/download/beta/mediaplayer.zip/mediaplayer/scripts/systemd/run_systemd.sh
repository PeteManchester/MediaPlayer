#! /bin/sh
DIRNAME="$( dirname "$0" )"
cd "${DIRNAME}"
exec java -jar "${DIRNAME}"/mediaplayer.jar


